from random import randrange
from chalice import NotFoundError, BadRequestError

import hashids
import boto3


PROFILE     =  "tudev"
TABLE_NAME  =  "urls"


class Urls:

    def __init__(self):
        self.session = boto3.Session(profile_name=PROFILE)
        self.dynamo = self.session.resource("dynamodb")
        self.table = self.dynamo.Table(TABLE_NAME)

        self._hasher = hashids.Hashids(salt="Your parrot is death")


    def shorten(self, long_url):
        uid = self._get_new_id()
        short_url = self._hasher.encode(uid)
        self.table.put_item(Item={"uid": uid, "long_url": long_url})
        return short_url


    def lengthen(self, short_url):
        try:
            uid = self._hasher.decode(short_url)[0]
        except:
            raise BadRequestError("'%s' is not a valid shourturl" % short_url)

        response = self.table.get_item(Key={"uid": uid})
        if "Item" in response:
            long_url = response["Item"]["long_url"]
            return long_url
        else:
            raise NotFoundError("Shorturl '%s' not recognized" % short_url)


    def _get_new_id(self):
        response = self.table.update_item(
            Key={"uid": -1},
            UpdateExpression="add last_id :inc",
            ExpressionAttributeValues={":inc": 1},
            ReturnValues="ALL_NEW"
        )
        return int(response["Attributes"]["last_id"])

